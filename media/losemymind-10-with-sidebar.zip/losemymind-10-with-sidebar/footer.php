<hr />
  <div id="footer">
  	<p class="center">
  		<a href="<?php bloginfo('url'); ?>">&copy; <?php bloginfo('name'); ?></a> * 
  		<a href="http://wordpress.org/">WordPress</a> * 
  		<a href="http://hellobmw.com/">LoseMyMind</a> * <!-- please keep this, thanks! -->
  		<a href="<?php bloginfo('rss2_url'); ?>">Feed <img src="<?php bloginfo('template_url') ?>/images/feed.gif" alt="feed" /></a>
  	</p>
  </div> <!-- #footer -->

</div> <!-- #page -->

<?php wp_footer(); ?>

<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->

</body>
</html>
