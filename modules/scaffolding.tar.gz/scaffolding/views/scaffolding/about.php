# Scaffolding Module  

Version 0.2  
Author: MHordecki <mhordecki@gmail.com>  
Website: <http://www.mhordecki.wordpress.com>

Kohana website: <http://www.kohanaphp.com>  
Kohana forums: <http://forum.kohanaphp.com> 

